ycH="hidden";
ycV="visible";
ycBU='http://tw.yimg.com/a/tw/js/';
ycMM1='<tr><td valign=middle bgcolor="#dcdcdc"><a href="';
ycMM2='" target=_new><img alt="alt" src="'+ycBU;
ycMM3='" width=14 height=14 border=0 hspace=4><font face="arial" size="1" color="#0000FF">';
ycMM4='</font></a></td></tr>';
ycRF=';return false"';
ycWSC=' onMouseOut="window.status=\'\';return true"';
ycWS1=ycRF+' onMouseOver="window.status=\'Minimize\';return true"'+ycWSC;
ycWS2=ycRF+' onMouseOver="window.status=\'Expand\';return true"'+ycWSC;
ycOCH='href="" onClick="javascript:yfiOC(';
ycL0='<div style="position: absolute; top: 0; left: 0; visibility: hidden" id=';
ycL1='><table border=2 cellpadding=0 cellspacing=0><tr><td valign=top bgcolor=#ffffff><table border=0 cellpadding=0 cellspacing=0 width=138><tr><td valign=top><img usemap=#';
ycL2=' id=bottomImage alt="nav" src="'+ycBU;
ycL3='" width=138 height=17 border=0></td></tr><tr><td valign=top align=center';
ycL4='<font face=Arial size=-2 color=Blue>';
var yvB;
var yvM;
var yvT;
var yvX=0;
var yvH;
var yvS=0;
var yvTO=15;
var yvBF=0;
var yvSID;
var yvSM=0;
var yvSMU;
var yvVP=0;
var yvVPU;
var yvSE=0;
var yvSEU;
var yviR="tw";
var yviGC=0;
var yviGCM;
var yviMN;
var yviTI=0;
var yviGA=0;
var yviGAW;
var yvTop;
function yfiPA(){
document.all.yl0.style.left=document.body.clientWidth-144;
document.all.yl1.style.left=document.body.clientWidth-144;
document.all.yl2.style.left=document.body.clientWidth-144;
document.all.yl3.style.left=document.body.clientWidth-144;
document.all.yl4.style.left=document.body.clientWidth-144;
}
function yfiWM(){
document.write('</font></a></td></tr></table></td></tr>');
if (yvSM){
document.write(ycMM1+yvSMU+ycMM2+'msg.gif'+ycMM3+'�ǰT������'+ycMM4);
}
if (yvVP){
document.write(ycMM1+yvVPU+ycMM2+'profile.gif'+ycMM3+'�ݧڪ��ӤH�ɮ�'+ycMM4);
}
if (yviGC){
document.write(ycMM1+yviGCM+ycMM2+'gc.gif'+ycMM3+'�ǰT���� '+yviMN+ycMM4);
}
document.write('</table></div>');
}
function yfiD(){
ycMa='<area shape=rect coords="2,2,84,14" href=http://tw.home.yahoo.com target=_new><area shape=rect coords="';
ycM0=ycMa+'87,2,101,14" href="http://help.yahoo.com/help/k1/geo/" target=_new>';
ycM1=ycMa+'104,2,118,14" href="" onClick="javascript:yfiOC(2)'+ycWS2+'>';
ycM2=ycMa+'121,2,135,14" ';
document.write('<map name=ym0>'+ycM0+ycM1+ycM2+ycOCH+'-1)'+ycRF+'" onMouseOver="window.status=\'Hide\';return true"'+ycWSC+'></map><map name=ym1>'+ycM0+ycM1+ycM2+ycOCH+'0)'+ycWS1+'></map><map name=ym2>'+ycM0+ycM2+ycOCH+'0)'+ycWS1+'></map>');
document.write(ycL0+'yl0'+ycL1+'ym0'+ycL2+'freeup.gif'+ycL3+' bgcolor=#ffffcc><a '+ycOCH+'2)'+ycWS2+'>'+ycL4+'<span id=div_yl0>'+yvT+'</span>');
yfiWM();
document.write(ycL0+'yl1'+ycL1+'ym1'+ycL2+'freemid.gif'+ycL3+'><a '+ycOCH+'2)'+ycWS2+'><span id=div_yl1>'+yvM+'</span></a></td></tr><tr><td align=center><a '+ycOCH+'2)'+ycWS2+'>'+ycL4+'��h�T��...');
yfiWM();
document.write(ycL0+'yl2'+ycL1+'ym2'+ycL2+'freedown.gif'+ycL3+'><span id=div_yl2>'+yvB+'</span></td></tr><tr><td align=center><a '+ycOCH+'0)'+ycWS1+'>'+ycL4+'[����]');
yfiWM();
document.write(ycL0+'yl3'+ycL1+'ym2'+ycL2+'freedown.gif'+ycL3+'><span id=div_yl3>'+yvM+'</span></td></tr><tr><td align=center><a '+ycOCH+'2)'+ycWS1+'>'+ycL4+'[����]');
yfiWM();
document.write(ycL0+'yl4'+ycL1+'ym0'+ycL2+'freeup.gif'+ycL3+' bgcolor=#ffffcc><span id=div_yl4>'+yvT+'</span>');
yfiWM();
}
function yfiOC(d){
yfiPA();
if (yviTI!=0){
clearTimeout(yviTI);
}
if (d==-1){
document.all.yl0.style.visibility=ycH;
document.all.yl1.style.visibility=ycH;
document.all.yl2.style.visibility=ycH;
document.all.yl3.style.visibility=ycH;
document.all.yl4.style.visibility=ycH;
}
if (d==0){
if (yvX==1){
document.all.yl0.style.visibility=ycH;
document.all.yl4.style.visibility=ycV;
} else {
document.all.yl0.style.visibility=ycV;
document.all.yl4.style.visibility=ycH;
}
document.all.yl1.style.visibility=ycH;
document.all.yl2.style.visibility=ycH;
document.all.yl3.style.visibility=ycH;
}
if (d==1){
document.all.yl0.style.visibility=ycH;
if (yvS==0){
document.all.yl1.style.visibility=ycV;
} else {
document.all.yl1.style.visibility=ycH;
}
document.all.yl2.style.visibility=ycH;
if (yvS==0){
document.all.yl3.style.visibility=ycH;
} else {
document.all.yl3.style.visibility=ycV;
}
document.all.yl4.style.visibility=ycH;
}
if (d==2){
document.all.yl0.style.visibility=ycH;
document.all.yl1.style.visibility=ycH;
document.all.yl2.style.visibility=ycV;
document.all.yl3.style.visibility=ycH;
document.all.yl4.style.visibility=ycH;
}
}
function yfiSA(){
if (yvS==0){
document.all.yl1.style.visibility=ycV;
} else {
document.all.yl3.style.visibility=ycV;
}
yviTI=setTimeout("yfiOC(0)",yvTO*1000);
}
function yfiCA(w){
var t=0;
if(!w){
w=self;
}
if(w._ypa){
t=w._ypa;
} else {
if(w.document.body){
t=w.document.body.clientWidth*w.document.body.clientHeight;
} else {
t=document.body.clientWidth*document.body.clientHeight;
}
w._ypa=t;
}
if(t>=yviGA){
yviGA=t;
yviGAW=w;
}
}
function yfiFF(w){
var i=0;
if (w.document.body.text || w.frames.length==0){
yfiCA(w);
return;
}
for(i=0;i<w.frames.length;i++){
if(w.frames[i].frames.length>0){
yfiFF(w.frames[i]);
} else {
yfiCA(w.frames[i]);
}
}
return;
}
function yfiFT(w) {
if (w.location.search.substring(1) == "r=1") {
return w;
} else if (parent != w) {
return yfiFT(parent);
} else {
return w;
}
}
function yfiSH(g){
var r=0;
yvTop=yfiFT(window);
if (g == 1) {
yfiB("g");
yvTop.gg=g;
}
if (window!=top){
yfiFF(yvTop);
if (yviGAW==self && !yvTop.ad){
r=1;
yvTop.ad=1;
}
} else {
r=1;
}
return r;
}
function yfiCF(){
yvTop.ad=0;
}
function yfiB(yvAd){
if (yvBF == 1){
 yvBF=0;
 //document.write('<IMG src="http://'+yviR+'.geocities.yahoo.com/pixel.gif?'+yvAd+'&'+Math.random()+'">');
 }
}
function yfiEA(g){
if(navigator.appName != "Microsoft Internet Explorer"){
return 0;
}
if (yfiSH(g)==1&&(!yvTop.gg||yvTop.gg!=1)){
yfiD();
document.write('<script language="JavaScript" type="text/javascript" src="'+yviContents+'"></scr');
document.write('ipt>');
yfiPA();
window.onresize=yfiPA;
window.onunload=yfiCF;
yfiB("a");
} else {
if (!yvTop.gg||yvTop.gg!=1){
yfiB("f");
} else {
yfiB("n");
}
}
}
function yfiID(yvB,yvM,yvTv,yvTm,yvSv,yvHv){
yvTO=yvTm;
yvS=yvSv;
if (yvHv!=''){
yvT='<a href='+yvHv+' target="_new"><font face=Arial size=-2 color=Blue>'+yvTv;
yvX=1;
} else {
yvT=yvTv;
}
if (yvX==0 && document.all.div_yl0)
document.all.div_yl0.innerHTML=yvT;
if (yvS==0 && document.all.div_yl1)
document.all.div_yl1.innerHTML=yvM;
if (document.all.div_yl2)
document.all.div_yl2.innerHTML=yvB;
if (yvS!=0 && document.all.div_yl3)
document.all.div_yl3.innerHTML=yvM;
if (yvX!=0 && document.all.div_yl4)
document.all.div_yl4.innerHTML=yvT;
yfiSA();
}

